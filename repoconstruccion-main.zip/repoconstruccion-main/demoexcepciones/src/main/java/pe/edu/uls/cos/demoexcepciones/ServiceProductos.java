package pe.edu.uls.cos.demoexcepciones;

import java.util.Date;

import org.springframework.stereotype.Service;

@Service 
public class ServiceProductos {

    public Producto registrarProducto(Producto nuevo) throws ProductoInvalidoException {
        if(nuevo.getNombre().length()<2){
            throw new ProductoInvalidoException("El producto debe tener un nombre de al menos 2 caracteres");
        }
        if(nuevo.getNombre().equals("mouse")){
            throw new ProductoInvalidoException("El producto ya existe en el sistema");
        }
        Date ahora = new Date();
        nuevo.setId((int) ahora.getTime());
        return nuevo;
    }
}